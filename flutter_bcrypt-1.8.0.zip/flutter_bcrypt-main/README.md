# flutter_bcrypt

A flutter bcrypt hashing plugin delegating to android &#x2F; ios native implementations.

The implementation on Android uses https://github.com/patrickfav/bcrypt/
The implementation on iOS uses https://github.com/felipeflorencio/BCryptSwift


# flutter_bcrypt
