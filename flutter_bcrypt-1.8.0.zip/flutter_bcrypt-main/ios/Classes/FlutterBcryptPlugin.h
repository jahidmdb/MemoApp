#import <Flutter/Flutter.h>

@interface FlutterBcryptPlugin : NSObject<FlutterPlugin>
@end
