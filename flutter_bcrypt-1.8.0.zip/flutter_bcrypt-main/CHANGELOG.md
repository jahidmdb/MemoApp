## 1.0.8

* Use Flutter v2 embedding, thanks https://github.com/ziakhan110 for the PR.

## 1.0.7

* Fix kotlin issue, thanks https://github.com/ziakhan110 for the PR.

## 1.0.6

* Null safety (thanks https://github.com/flawnn for the PR.)

## 1.0.5

* iOS version conflicts resolved

## 1.0.3

* Improved documentation, format health for flutter packages

## 1.0.0

* Initial release with support for iOS and Android



